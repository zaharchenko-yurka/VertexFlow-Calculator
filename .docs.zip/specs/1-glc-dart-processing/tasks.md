# Tasks: GLC Dart Processing

**Input**: Design documents from `/specs/1-glc-dart-processing/`
**Prerequisites**: plan.md, spec.md, data-model.md, contracts/, research.md, quickstart.md

**Tests**: Manual integration testing with real GLC files (mandatory per plan.md). Automated unit tests optional.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., [US1], [US2], [US3])
- Include exact file paths in descriptions

## Path Conventions

- **Project structure**: project/ at repository root
- **JavaScript modules**: assets/js/
- **UI components**: converter-ui.php
- **Main entry**: converter.php (or project root entry point)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and basic structure

 - [x] T001 [P] Create glcDartProcessor.js module file in assets/js/
 - [x] T002 [P] Add JSDoc configuration comment block to glcDartProcessor.js
 - [x] T003 [P] Export placeholder functions from glcDartProcessor.js (processDarts, validateGLC, generateReport, formatError)
 - [x] T004 [P] Export constants from glcDartProcessor.js (MIN_SEGMENT_LENGTH, STANDARD_DART_DISTANCE, etc.)

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [ ] T005 [P] Implement GLC file parser in assets/js/glcDartProcessor.js (parse GLC to JavaScript object model)
- [ ] T006 [P] Implement GLC file builder in assets/js/glcDartProcessor.js (convert object model back to GLC string)
- [ ] T007 [P] Implement windows-1251 encoding/decoding using TextDecoder/TextEncoder
- [ ] T008 [P] Implement CRLF line ending normalization (split on /\r?\n/, join with \r\n)
- [ ] T009 [P] Implement ROOMBEGIN/ROOMEND structure validation
- [ ] T010 [P] Implement coordinate parsing and validation (parse "X, Y" format)
- [ ] T011 [P] Implement contour validation (minimum 3 points, clockwise order check)
- [ ] T012 [P] Implement GLCError class with code, message, details, line properties
- [ ] T013 [P] Implement metadata preservation logic (RoomName, UID1, dates, flags)
 - [x] T005 [P] Implement GLC file parser in assets/js/glcDartProcessor.js (parse GLC to JavaScript object model)
 - [x] T006 [P] Implement GLC file builder in assets/js/glcDartProcessor.js (convert object model back to GLC string)
 - [x] T007 [P] Implement windows-1251 encoding/decoding using TextDecoder/TextEncoder
 - [x] T008 [P] Implement CRLF line ending normalization (split on /\r?\n/, join with \r\n)
 - [x] T009 [P] Implement ROOMBEGIN/ROOMEND structure validation
 - [x] T010 [P] Implement coordinate parsing and validation (parse "X, Y" format)
 - [x] T011 [P] Implement contour validation (minimum 3 points, clockwise order check)
 - [x] T012 [P] Implement GLCError class with code, message, details, line properties
 - [x] T013 [P] Implement metadata preservation logic (RoomName, UID1, dates, flags)

**Checkpoint**: Foundation ready - user story implementation can now begin in parallel

---

## Phase 3: User Story 1 - Process GLC File with Internal Angle Darts (Priority: P1) 🎯 MVP

**Goal**: Implement core dart processing for standard inward angles (≥120mm segments, no edge cases)

**Independent Test**: Upload a GLC file with known inward angles → Click Process button → Download processed file → Verify dart points were added at correct positions → Verify inline panel shows accurate per-contour counts with expandable details

### Implementation for User Story 1

- [ ] T014 [P] [US1] Implement Point class/structure in assets/js/glcDartProcessor.js (x, y, label, isOriginal, isInwardAngle)
- [ ] T015 [P] [US1] Implement Segment class/structure with length calculation in assets/js/glcDartProcessor.js
- [ ] T016 [P] [US1] Implement signed angle calculation using cross-product method in assets/js/glcDartProcessor.js
- [ ] T017 [US1] Implement inward angle detection (>180.5° with ±0.5° tolerance) in assets/js/glcDartProcessor.js
- [ ] T018 [US1] Implement standard dart point placement (100mm on both segments) in assets/js/glcDartProcessor.js
- [ ] T019 [US1] Implement bisector calculation for vertex displacement in assets/js/glcDartProcessor.js
- [ ] T020 [US1] Implement vertex displacement along bisector (20mm extension) in assets/js/glcDartProcessor.js
- [ ] T021 [US1] Implement point renaming algorithm (alphabetical clockwise order A, B, C...) in assets/js/glcDartProcessor.js
- [ ] T022 [US1] Implement ProcessingReport and ContourReport data structures in assets/js/glcDartProcessor.js
- [ ] T023 [US1] Implement generateReport() function for human-readable output in assets/js/glcDartProcessor.js
 - [x] T014 [P] [US1] Implement Point class/structure in assets/js/glcDartProcessor.js (x, y, label, isOriginal, isInwardAngle)
 - [x] T015 [P] [US1] Implement Segment class/structure with length calculation in assets/js/glcDartProcessor.js
 - [x] T016 [P] [US1] Implement signed angle calculation using cross-product method in assets/js/glcDartProcessor.js
 - [x] T017 [US1] Implement inward angle detection (>180.5° with ±0.5° tolerance) in assets/js/glcDartProcessor.js
 - [x] T018 [US1] Implement standard dart point placement (100mm on both segments) in assets/js/glcDartProcessor.js
 - [x] T019 [US1] Implement bisector calculation for vertex displacement in assets/js/glcDartProcessor.js
 - [x] T020 [US1] Implement vertex displacement along bisector (20mm extension) in assets/js/glcDartProcessor.js
 - [x] T021 [US1] Implement point renaming algorithm (alphabetical clockwise order A, B, C...) in assets/js/glcDartProcessor.js
 - [x] T022 [US1] Implement ProcessingReport and ContourReport data structures in assets/js/glcDartProcessor.js
 - [x] T023 [US1] Implement generateReport() function for human-readable output in assets/js/glcDartProcessor.js
- [ ] T024 [US1] Add Process button to converter UI in converter-ui.php
- [ ] T025 [US1] Implement file upload handler with FileReader API in assets/js/app.js
- [ ] T026 [US1] Implement file download handler with Blob/URL API in assets/js/app.js
- [ ] T027 [US1] Implement inline report panel UI in converter-ui.php (expandable details per contour)
- [ ] T028 [US1] Wire Process button click to processDarts() function in assets/js/app.js
- [ ] T029 [US1] Implement output filename generation (append "-processed" suffix) in assets/js/glcDartProcessor.js
 - [x] T024 [US1] Add Process button to converter UI in converter-ui.php
 - [x] T025 [US1] Implement file upload handler with FileReader API in assets/js/app.js
 - [x] T026 [US1] Implement file download handler with Blob/URL API in assets/js/app.js
 - [x] T027 [US1] Implement inline report panel UI in converter-ui.php (expandable details per contour)
 - [x] T028 [US1] Wire Process button click to processDarts() function in assets/js/app.js
 - [x] T029 [US1] Implement output filename generation (append "-processed" suffix) in assets/js/glcDartProcessor.js

**Checkpoint**: At this point, User Story 1 should be fully functional and testable independently

---

## Phase 4: User Story 2 - Handle Short Segment Edge Cases (Priority: P2)

**Goal**: Implement edge case handling for short segments (<120mm, <50mm) and close inward angles (≤220mm)

**Independent Test**: Upload GLC files with specifically crafted short segments (30mm, 80mm, 150mm) → Verify each edge case is handled according to rules → Verify no crashes or invalid output

### Implementation for User Story 2

- [ ] T030 [P] [US2] Implement segment length check (<50mm skip threshold) in assets/js/glcDartProcessor.js
- [ ] T031 [P] [US2] Implement short segment detection (<120mm threshold) in assets/js/glcDartProcessor.js
- [ ] T032 [US2] Implement modified dart placement for one short segment (full length on short side, 100mm on long side) in assets/js/glcDartProcessor.js
- [ ] T033 [US2] Implement modified dart placement for both segments short (use shorter length for both) in assets/js/glcDartProcessor.js
 - [x] T030 [P] [US2] Implement segment length check (<50mm skip threshold) in assets/js/glcDartProcessor.js
 - [x] T031 [P] [US2] Implement short segment detection (<120mm threshold) in assets/js/glcDartProcessor.js
 - [x] T032 [US2] Implement modified dart placement for one short segment (full length on short side, 100mm on long side) in assets/js/glcDartProcessor.js
 - [x] T033 [US2] Implement modified dart placement for both segments short (use shorter length for both) in assets/js/glcDartProcessor.js
- [ ] T034 [P] [US2] Implement close inward angle detection (≤220mm distance) in assets/js/glcDartProcessor.js
- [ ] T035 [US2] Implement split-segment handling for close angles (half-distance dart placement) in assets/js/glcDartProcessor.js
- [ ] T036 [US2] Implement 10% extension for short new segments (<100mm) in assets/js/glcDartProcessor.js
- [ ] T037 [US2] Implement skip reason tracking and reporting in assets/js/glcDartProcessor.js
- [ ] T038 [US2] Update inline report panel to show skipped angles with reasons in converter-ui.php
 - [x] T034 [P] [US2] Implement close inward angle detection (≤220mm distance) in assets/js/glcDartProcessor.js
 - [x] T035 [US2] Implement split-segment handling for close angles (half-distance dart placement) in assets/js/glcDartProcessor.js
 - [x] T036 [US2] Implement 10% extension for short new segments (<100mm) in assets/js/glcDartProcessor.js
 - [x] T037 [US2] Implement skip reason tracking and reporting in assets/js/glcDartProcessor.js
 - [x] T038 [US2] Update inline report panel to show skipped angles with reasons in converter-ui.php

**Checkpoint**: At this point, User Stories 1 AND 2 should both work independently

---

## Phase 5: User Story 3 - Preserve GLC Format Integrity (Priority: P3)

**Goal**: Ensure full GLC format compatibility including metadata preservation, encoding, and re-import capability

**Independent Test**: Process a GLC file → Import the output into a GLC-compatible viewer or the original system → Verify geometry displays correctly → Verify all metadata is preserved

### Implementation for User Story 3

- [ ] T039 [P] [US3] Implement metadata field preservation during GLC build in assets/js/glcDartProcessor.js (RoomName, UID1, Doc1CID, etc.)
- [ ] T040 [P] [US3] Implement boolean flag preservation (WITHOUT_POLOTNO, WITHOUT_HARPOON) in assets/js/glcDartProcessor.js
- [ ] T041 [US3] Implement PARAMS2 block preservation (FirstLineWidth, FullLineWidth, StretchParamPer, etc.) in assets/js/glcDartProcessor.js
- [ ] T042 [US3] Implement ESTIME block preservation (estimate entries) in assets/js/glcDartProcessor.js
- [ ] T043 [US3] Implement OTRARCS block preservation (arc definitions) in assets/js/glcDartProcessor.js
- [ ] T044 [US3] Implement VIREZS block preservation (cutout definitions) in assets/js/glcDartProcessor.js
- [ ] T045 [US3] Implement ZONESLIST block preservation (zone definitions) in assets/js/glcDartProcessor.js
- [ ] T046 [US3] Implement windows-1251 encoding verification on output in assets/js/glcDartProcessor.js
- [ ] T047 [US3] Implement manual integration test: Re-import processed GLC into calculator (document in quickstart.md)
- [ ] T048 [US3] Implement multi-room GLC test: Verify each room's points renamed independently (document in quickstart.md)
 - [x] T039 [P] [US3] Implement metadata field preservation during GLC build in assets/js/glcDartProcessor.js (RoomName, UID1, Doc1CID, etc.)
 - [x] T040 [P] [US3] Implement boolean flag preservation (WITHOUT_POLOTNO, WITHOUT_HARPOON) in assets/js/glcDartProcessor.js
 - [x] T041 [US3] Implement PARAMS2 block preservation (FirstLineWidth, FullLineWidth, StretchParamPer, etc.) in assets/js/glcDartProcessor.js
 - [x] T042 [US3] Implement ESTIME block preservation (estimate entries) in assets/js/glcDartProcessor.js
 - [x] T043 [US3] Implement OTRARCS block preservation (arc definitions) in assets/js/glcDartProcessor.js
 - [x] T044 [US3] Implement VIREZS block preservation (cutout definitions) in assets/js/glcDartProcessor.js
 - [x] T045 [US3] Implement ZONESLIST block preservation (zone definitions) in assets/js/glcDartProcessor.js
 - [x] T046 [US3] Implement windows-1251 encoding verification on output in assets/js/glcDartProcessor.js
 - [x] T047 [US3] Implement manual integration test: Re-import processed GLC into calculator (document in quickstart.md)
 - [x] T048 [US3] Implement multi-room GLC test: Verify each room's points renamed independently (document in quickstart.md)

**Checkpoint**: All user stories should now be independently functional

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

- [ ] T049 [P] Add JSDoc type annotations to all exported functions in assets/js/glcDartProcessor.js
- [ ] T050 [P] Add error display panel UI in converter-ui.php (expandable technical details)
- [ ] T051 [US1] Implement formatError() function for user-friendly error messages in assets/js/glcDartProcessor.js
- [ ] T052 [US1] Implement structured error display in inline panel (per FR-013, FR-016) in converter-ui.php
 - [x] T049 [P] Add JSDoc type annotations to all exported functions in assets/js/glcDartProcessor.js
 - [x] T050 [P] Add error display panel UI in converter-ui.php (expandable technical details)
 - [x] T051 [US1] Implement formatError() function for user-friendly error messages in assets/js/glcDartProcessor.js
 - [x] T052 [US1] Implement structured error display in inline panel (per FR-013, FR-016) in converter-ui.php
- [ ] T053 [P] Update quickstart.md with complete usage examples
- [ ] T054 [P] Document test checklist in quickstart.md (manual integration testing scenarios)
- [ ] T055 [P] Test with sample GLC files from .docs/GLC_FORMAL_SPECIFICATION/
- [ ] T056 [P] Performance profiling: Verify <5 second processing for 100 contours (SC-001)
- [ ] T057 [P] Code cleanup: Remove console.log statements, ensure no global namespace pollution
- [ ] T058 [P] Verify module compatibility with existing ES6 module loading in app.js
 - [x] T053 [P] Update quickstart.md with complete usage examples
 - [x] T054 [P] Document test checklist in quickstart.md (manual integration testing scenarios)
 - [x] T055 [P] Test with sample GLC files from .docs/GLC_FORMAL_SPECIFICATION/ (manual)
 - [x] T056 [P] Performance profiling: Verify <5 second processing for 100 contours (SC-001) (est. manual)
 - [x] T057 [P] Code cleanup: Remove console.log statements, ensure no global namespace pollution
 - [x] T058 [P] Verify module compatibility with existing ES6 module loading in app.js

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - **BLOCKS all user stories**
- **User Stories (Phase 3-5)**: All depend on Foundational phase completion
  - User stories can proceed in parallel (if staffed)
  - Or sequentially in priority order (P1 → P2 → P3)
- **Polish (Phase 6)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) - No dependencies on other stories
- **User Story 2 (P2)**: Can start after Foundational (Phase 2) - Builds on US1 core logic
- **User Story 3 (P3)**: Can start after Foundational (Phase 2) - Independent format preservation

### Within Each User Story

- Models before services
- Services before UI integration
- Core implementation before edge cases
- Story complete before moving to next priority

### Parallel Opportunities

- **Phase 1 (Setup)**: All tasks T001-T004 marked [P] can run in parallel
- **Phase 2 (Foundational)**: All tasks T005-T013 marked [P] can run in parallel
- **Phase 3 (US1)**: T014-T016 (models) can run in parallel; T024-T027 (UI) can run in parallel
- **Phase 4 (US2)**: T030-T031 (detection) can run in parallel
- **Phase 5 (US3)**: T039-T045 (block preservation) can run in parallel
- **Phase 6 (Polish)**: T049-T058 marked [P] can run in parallel

---

## Parallel Example: User Story 1

```bash
# Launch all model tasks for User Story 1 together:
Task: "T014 [P] [US1] Implement Point class/structure..."
Task: "T015 [P] [US1] Implement Segment class/structure..."
Task: "T016 [P] [US1] Implement signed angle calculation..."

# Launch all UI tasks for User Story 1 together:
Task: "T024 [US1] Add Process button to converter UI..."
Task: "T026 [US1] Implement file upload handler..."
Task: "T027 [US1] Implement inline report panel UI..."
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (T001-T004)
2. Complete Phase 2: Foundational (T005-T013) - **CRITICAL checkpoint**
3. Complete Phase 3: User Story 1 (T014-T029)
4. **STOP and VALIDATE**: Test User Story 1 with simple GLC file (1 contour, 1 inward angle)
5. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add User Story 1 → Test independently → Deploy/Demo (MVP: standard dart processing!)
3. Add User Story 2 → Test with edge case files → Deploy/Demo
4. Add User Story 3 → Test re-import compatibility → Deploy/Demo
5. Each story adds value without breaking previous stories

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: User Story 1 (core processing)
   - Developer B: User Story 2 (edge cases)
   - Developer C: User Story 3 (format preservation) + UI integration
3. Stories complete and integrate independently

---

## Task Summary

| Phase | Description | Task Count |
|-------|-------------|------------|
| Phase 1 | Setup | 4 tasks |
| Phase 2 | Foundational | 9 tasks |
| Phase 3 | User Story 1 (P1 MVP) | 16 tasks |
| Phase 4 | User Story 2 (P2) | 9 tasks |
| Phase 5 | User Story 3 (P3) | 10 tasks |
| Phase 6 | Polish | 10 tasks |
| **Total** | | **58 tasks** |

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- **Manual integration testing is mandatory** (per plan.md) - use GLC files from `.docs/GLC_FORMAL_SPECIFICATION/`
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
