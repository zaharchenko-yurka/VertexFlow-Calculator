# Data Model: GLC Dart Processing

**Feature**: 1-glc-dart-processing  
**Date**: 2026-03-10  
**Purpose**: Define data structures for contour geometry and dart processing

---

## Core Entities

### Contour

A closed polygon representing a single ceiling/room outline.

**Fields**:
- `id`: string - Unique identifier (from GLC RoomName or generated UID)
- `points`: Point[] - Ordered array of contour vertices in clockwise order
- `metadata`: RoomMetadata - Associated room information from GLC file
- `isProcessed`: boolean - Flag indicating if dart processing has been applied

**Relationships**:
- Contains 3+ Point entities (minimum for valid polygon)
- May contain 0+ DartCut entities after processing
- Belongs to GLCFile root container

**Validation Rules**:
- MUST have at least 3 points (FR-invalid if fewer)
- Points MUST form closed polygon (first == last, or implicitly closed)
- Points MUST be in clockwise order (per GLC format convention)

**State Transitions**:
```
Raw → Validated → Analyzed → Processed → Renamed
  │         │           │          │         │
  │         │           │          │         └─ Points renamed A,B,C...
  │         │           │          └─ Dart cuts added
  │         │           └─ Inward angles identified
  │         └─ Structure validated
  └─ Loaded from GLC file
```

---

### Point

A 2D coordinate representing a contour vertex.

**Fields**:
- `x`: number - X coordinate in millimeters (FLOAT precision)
- `y`: number - Y coordinate in millimeters (FLOAT precision)
- `label`: string - Alphabetical label (A, B, C, ...)
- `isOriginal`: boolean - True if from original contour, false if dart point
- `isInwardAngle`: boolean - True if this vertex is an inward-pointing angle (>180°)

**Derived Properties**:
- `angle`: number - Interior angle at this vertex in degrees (0-360)
- `isInward`: boolean - Computed from angle: `angle > 180°` (with ±0.5° tolerance)
- `prevSegment`: Segment - Segment from previous point to this point
- `nextSegment`: Segment - Segment from this point to next point

**Validation Rules**:
- Coordinates MUST be valid numbers (not NaN, Infinity)
- Coordinates SHOULD be within reasonable bounds (-10000 to +10000 mm)

---

### Segment

A line segment between two consecutive contour points.

**Fields**:
- `start`: Point - Starting vertex
- `end`: Point - Ending vertex
- `length`: number - Euclidean distance in millimeters

**Derived Properties**:
- `vector`: {x: number, y: number} - Direction vector (end - start)
- `unitVector`: {x: number, y: number} - Normalized direction vector
- `midpoint`: {x: number, y: number} - Center point of segment

**Validation Rules**:
- Length MUST be >= 0
- Length < 50mm triggers special handling (FR-004)
- Length < 120mm triggers modified dart placement (FR-005, FR-006)

---

### InwardAngle

An inward-pointing vertex requiring dart processing.

**Fields**:
- `vertex`: Point - The inward angle vertex
- `prevSegment`: Segment - Segment approaching the vertex
- `nextSegment`: Segment - Segment leaving the vertex
- `angle`: number - Interior angle in degrees (>180°)
- `skipReason`: string | null - Reason for skipping, if not processed

**Derived Properties**:
- `canProcess`: boolean - `true` if both segments >= 50mm
- `isCloseToNeighbor`: boolean - `true` if next inward angle <= 220mm away
- `prevDartDistance`: number - Distance for dart point on prev segment (100mm or segment.length)
- `nextDartDistance`: number - Distance for dart point on next segment (100mm or segment.length)

**Validation Rules**:
- Angle MUST be > 180.5° (accounting for ±0.5° tolerance)
- Both segments MUST exist (contour integrity)

---

### DartCut

The geometric modification created at an inward angle.

**Fields**:
- `inwardAngle`: InwardAngle - Reference to processed inward angle
- `prevDartPoint`: Point - Dart point on previous segment
- `nextDartPoint`: Point - Dart point on next segment
- `displacedVertex`: Point - New position of original inward vertex
- `prevExtension`: number - Extension distance for prev segment (20mm or 10%)
- `nextExtension`: number - Extension distance for next segment (20mm or 10%)

**Derived Properties**:
- `cutArea`: number - Area of triangular dart cut in mm²
- `cutDepth`: number - Maximum depth of dart cut from original vertex

**Validation Rules**:
- Dart points MUST lie on their respective segments
- Displaced vertex MUST be inside contour (toward interior)
- Cut MUST NOT self-intersect with other contour segments

---

### RoomMetadata

GLC room-level metadata preserved during processing.

**Fields**:
- `roomName`: string - Room identifier
- `uid1`: string | null - Primary UID
- `doc1Cid`: string | null - Document CID
- `roomHeight`: number | null - Room height in mm
- `date1`: string | null - Date field 1
- `date2`: string | null - Date field 2
- `roomWWidth`: number | null - Room width
- `numOrCharGgo`: string | null - GGO character/number
- `withoutPolotno`: boolean - Flag: exclude fabric
- `withoutHarpoon`: boolean - Flag: exclude harpoon

**Validation Rules**:
- All fields OPTIONAL (preserve whatever exists in input)
- String fields preserved exactly (including encoding)

---

### GLCFile

Root container for GLC data.

**Fields**:
- `contours`: Contour[] - Array of room contours
- `globalMetadata`: Map<string, string> - File-level key-value pairs
- `encoding`: string - File encoding (windows-1251)
- `lineEnding`: string - Line ending style (CRLF)
- `processingReport`: ProcessingReport | null - Results after processing

**Validation Rules**:
- MUST have at least 1 contour (FR-invalid if empty)
- Encoding MUST be windows-1251
- Line ending MUST be CRLF

---

### ProcessingReport

Summary of dart processing results.

**Fields**:
- `totalContours`: number - Count of contours in file
- `processedContours`: number - Count of contours with at least one dart
- `totalInwardAngles`: number - Total inward angles found
- `processedAngles`: number - Total angles that received dart cuts
- `skippedAngles`: number - Total angles skipped (< 50mm segments or self-intersection)
- `contourDetails`: ContourReport[] - Per-contour breakdown

**Derived Properties**:
- `successRate`: number - `processedAngles / totalInwardAngles * 100`

---

### ContourReport

Per-contour processing summary.

**Fields**:
- `contourId`: string - Reference to contour
- `inwardAnglesFound`: number - Count of inward angles detected
- `dartsCreated`: number - Count of dart cuts added
- `dartsSkipped`: number - Count of angles skipped
- `skipReasons`: string[] - Reasons for skipping (if any)

---

## Data Flow Diagram

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  GLC File   │────▶│  GLC Parser  │────▶│  GLCFile    │
│  (binary)   │     │              │     │  (object)   │
└─────────────┘     └──────────────┘     └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐
                                       │  Contour[]  │
                                       │  Point[]    │
                                       └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐
                                       │  InwardAngle│
                                       │  Finder     │
                                       └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐
                                       │  DartCut    │
                                       │  Generator  │
                                       └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐
                                       │  Point      │
                                       │  Renamer    │
                                       └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐
                                       │  Processing │
                                       │  Report     │
                                       └─────────────┘
                                                │
                                                ▼
                                       ┌─────────────┐     ┌─────────────┐
                                       │  GLC Builder│────▶│  GLC File   │
                                       │             │     │  (output)   │
                                       └─────────────┘     └─────────────┘
```

---

## Type Definitions (TypeScript-like)

```typescript
interface Point {
  x: number;
  y: number;
  label: string;
  isOriginal: boolean;
  isInwardAngle: boolean;
}

interface Segment {
  start: Point;
  end: Point;
  length: number;
  vector: { x: number; y: number };
  unitVector: { x: number; y: number };
  midpoint: { x: number; y: number };
}

interface InwardAngle {
  vertex: Point;
  prevSegment: Segment;
  nextSegment: Segment;
  angle: number;
  skipReason: string | null;
  canProcess: boolean;
  isCloseToNeighbor: boolean;
  prevDartDistance: number;
  nextDartDistance: number;
}

interface DartCut {
  inwardAngle: InwardAngle;
  prevDartPoint: Point;
  nextDartPoint: Point;
  displacedVertex: Point;
  prevExtension: number;
  nextExtension: number;
}

interface RoomMetadata {
  roomName: string;
  uid1: string | null;
  doc1Cid: string | null;
  roomHeight: number | null;
  date1: string | null;
  date2: string | null;
  roomWWidth: number | null;
  numOrCharGgo: string | null;
  withoutPolotno: boolean;
  withoutHarpoon: boolean;
}

interface Contour {
  id: string;
  points: Point[];
  metadata: RoomMetadata;
  isProcessed: boolean;
}

interface ProcessingReport {
  totalContours: number;
  processedContours: number;
  totalInwardAngles: number;
  processedAngles: number;
  skippedAngles: number;
  contourDetails: ContourReport[];
}

interface ContourReport {
  contourId: string;
  inwardAnglesFound: number;
  dartsCreated: number;
  dartsSkipped: number;
  skipReasons: string[];
}

interface GLCFile {
  contours: Contour[];
  globalMetadata: Map<string, string>;
  encoding: string;
  lineEnding: string;
  processingReport: ProcessingReport | null;
}
```

---

## Validation Rules Summary

| Entity | Rule | Source |
|--------|------|--------|
| Contour | Minimum 3 points | FR-invalid geometry |
| Contour | Clockwise point order | GLC format spec |
| Point | Valid coordinates (not NaN) | Data integrity |
| Segment | Length >= 50mm for processing | FR-004 |
| Segment | Length < 120mm → modified placement | FR-005, FR-006 |
| InwardAngle | Angle > 180.5° (with tolerance) | Clarification Q3 |
| DartCut | No self-intersection | Edge case spec |
| GLCFile | At least 1 contour | FR-001 |
| GLCFile | Windows-1251 encoding | GLC format spec |
| GLCFile | CRLF line endings | GLC format spec |
