# Implementation Plan: GLC Dart Processing

**Branch**: `1-glc-dart-processing` | **Date**: 2026-03-10 | **Spec**: [specs/1-glc-dart-processing/spec.md](../spec.md)
**Input**: Client-side GLC contour processing for internal angle dart creation to reduce wrinkle risk in stretch ceiling installation

## Summary

Build a client-side GLC contour processing module that automatically identifies inward-pointing angles (>180°) in ceiling contours and creates dart cuts (вытачки) to reduce wrinkle formation during installation on shadow/floating profiles. The module processes GLC files uploaded by users, adds dart points according to precise geometric rules (100mm standard, edge case handling for short segments), and outputs modified GLC files with preserved metadata and proper point renaming.

## Technical Context

**Language/Version**: JavaScript ES6+ (browser environment)
**Primary Dependencies**: None (vanilla JavaScript, no frameworks)
**Storage**: N/A (client-side file processing, no persistence)
**Testing**: Manual integration testing with real GLC files (mandatory)
**Target Platform**: Modern browsers (ES6 module support required)
**Project Type**: WordPress plugin client-side feature module
**Performance Goals**: Process files with up to 100 contours in under 5 seconds
**Constraints**: Client-side execution only, windows-1251 encoding, CRLF line endings, ±0.5° angle tolerance
**Scale/Scope**: Single feature module within the project structure
**Configuration**: All magic numbers centralized in [`constants.md`](constants.md) with Ukrainian comments

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Compliance | Justification |
|-----------|------------|---------------|
| I. Client-Side First | ✅ PASS | All dart processing executes in browser via new glcDartProcessor.js module; no server computation |
| II. Shortcode Integration | ✅ PASS | Feature integrates via existing `[dxf_glc_converter]` shortcode; no admin configuration required |
| III. GLC Format Fidelity | ✅ PASS | Maintains windows-1251 encoding, CRLF line endings, preserves all metadata, validates structure |
| IV. Design Consistency | ✅ PASS | UI (inline panel, Process button) follows the project design system (see `specs/design-system.json`) |
| V. Modular JavaScript Architecture | ✅ PASS | New glcDartProcessor.js module with single responsibility, pure functions, JSDoc annotations |

**Gate Result**: ✅ ALL PASS - Proceed to Phase 0 research

## Project Structure

### Documentation (this feature)

```text
specs/1-glc-dart-processing/
├── plan.md              # This file
├── research.md          # Phase 0 output (geometric algorithms, GLC parsing patterns)
├── data-model.md        # Phase 1 output (contour representation, dart geometry)
├── quickstart.md        # Phase 1 output (module usage examples)
├── constants.md         # All configuration values with Ukrainian comments
├── contracts/           # Phase 1 output (GLC format contract, module API)
└── tasks.md             # Phase 2 output (via /speckit.tasks)
```

### Source Code (repository root)

```text
glc-dart-processor/   # NEW plugin: independent from dxf-glc-converter
├── glc-dart-processor.php
└── assets/
    ├── style.css
    └── js/
        └── glcDartProcessor.js    # NEW: Dart processing module (Phase 1)
```

**Structure Decision**: Single project structure with new `glcDartProcessor.js` module added to `assets/js/` directory. Module follows the established ES6 module pattern used by existing modules (dxfParser.js, contourBuilder.js, etc.).

## Complexity Tracking

> **No constitution violations - all principles pass without justification required**
