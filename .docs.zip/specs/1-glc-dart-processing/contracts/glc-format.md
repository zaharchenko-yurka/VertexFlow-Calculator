# Contract: GLC File Format

**Feature**: 1-glc-dart-processing  
**Date**: 2026-03-10  
**Purpose**: Define GLC format contract for dart processing module

---

## Format Specification

### Encoding

- **Character Set**: Windows-1251 (Cyrillic)
- **BOM**: None
- **Line Endings**: CRLF (`\r\n`)

### File Structure

```
[GLOBAL_PREAMBLE]     ; Optional key-value pairs
ROOMBEGIN             ; Start of first room block
  [ROOM_HEADER]       ; Room metadata
  [POINTS_BLOCK]      ; Contour geometry
  [OTRARCS_BLOCK]     ; Arc definitions
  [BLUEPOINTS_BLOCK]  ; Additional points
  [OTRLIST_BLOCK]     ; Segment list
  [DIMLINES_BLOCK]    ; Dimension lines
  STARTPOINT          ; Starting point indicator
  [VIREZS_BLOCK]      ; Cutouts
  [GLOBPLAN_LINES]    ; Global plan lines
  [ALL_LINESLIST]     ; Extended drawing (optional)
  [ZONESLIST_BLOCK]   ; Zone definitions
  [ALLDIMLINES_BLOCK] ; All dimension lines
  [ESTIME_BLOCK]      ; Estimate entries
  [ROOM_TAIL]         ; Room footer
  PARAMS2             ; Additional parameters
ROOMEND               ; End of room block
[REPEAT ROOMBEGIN...ROOMEND for additional rooms]
[TRAILING_NEWLINE]    ; Optional final newline
```

---

## Required Blocks for Dart Processing

### ROOMBEGIN / ROOMEND

**Format**:
```
ROOMBEGIN
...
ROOMEND
```

**Validation**:
- MUST have at least one ROOMBEGIN/ROOMEND pair
- MUST be balanced (count equal)
- MUST appear in correct order (ROOMBEGIN before ROOMEND)

**Error**: `GLC_INVALID_STRUCTURE: Missing ROOMBEGIN at line {N}`

---

### Room Header Keys

| Key | Type | Required | Description |
|-----|------|----------|-------------|
| `RoomName` | string | Yes | Room identifier |
| `UID1` | GUID | No | Primary UID |
| `Doc1CID` | string | No | Document CID |
| `RoomHeight` | number | No | Room height (mm) |
| `Date1` | date | No | Date field 1 |
| `Date2` | date | No | Date field 2 |
| `RoomWWidth` | number | No | Room width (mm) |
| `NumOrCharGgo` | string | No | GGO character/number |
| `WITHOUT_POLOTNO` | boolean | No | Exclude fabric flag |
| `WITHOUT_HARPOON` | boolean | No | Exclude harpoon flag |

**Format**: `Key Value` (space-separated, single line per key)

**Example**:
```
RoomName Living Room
UID1 953C8771-99CA-4D40-A98E-FA85C774D591
RoomHeight 2700
WITHOUT_POLOTNO False
```

---

### Points Block

**Keys**: `AnglePoint`, `NPLine`, `PoBeg`, `PoEnd`

**Format**:
```
AnglePoint X, Y
NPLine N
PoBeg X, Y
PoEnd X, Y
```

**Coordinate Format**: `X, Y` (comma-separated, decimal dot, space after comma)

**Example**:
```
AnglePoint 7556.56, 5599.32
AnglePoint 8234.12, 6011.45
AnglePoint 7890.00, 6500.00
NPLine 3
```

**Validation**:
- MUST have at least 3 points for valid contour
- Coordinates MUST be valid numbers
- Points MUST be in clockwise order

**Error**: `GLC_INVALID_COORDINATE: Parse failure at line {N}`

---

### Arc Block (OTRARCS)

**Keys**: `ArcPoint`, `ArcHei`, `IdntBeg`, `IdntEnd`, `JValue`

**Format**:
```
ArcPoint X, Y
ArcHei H
IdntBeg N
IdntEnd M
JValue V
```

**Note**: Arcs are preserved but not modified by dart processing

---

### Estimate Block (ESTIME)

**Keys**: `ART_NO`, `Name`, `Units`, `Kol`, `Cena`, `GrpID`

**Format**:
```
ART_NO value
Name value
Units value
Kol value
Cena value
GrpID value
```

**Note**: Estimate entries are preserved unchanged

---

### Params2 Block

**Keys**: `FirstLineWidth`, `FullLineWidth`, `StretchParamPer`, `StretchParamPer_2`, `ColorLineName`, `LineLineName`, `ArtNoName`

**Format**:
```
FirstLineWidth value
FullLineWidth value
StretchParamPer value
StretchParamPer_2 value
ColorLineName value
LineLineName value
ArtNoName value
```

**Note**: Parameters preserved unchanged

---

## Output Guarantees

The dart processing module guarantees:

### Preserved Elements

- ✅ All original metadata (RoomName, UID1, dates, etc.)
- ✅ All original geometry (points, arcs, cutouts, zones)
- ✅ All estimate entries
- ✅ All parameter values
- ✅ File encoding (windows-1251)
- ✅ Line endings (CRLF)
- ✅ Block structure and order

### Modified Elements

- ⚠️ Point coordinates (dart points added, vertex displaced)
- ⚠️ Point count (increased by 2 per dart cut)
- ⚠️ Point labels (renamed alphabetically clockwise)
- ⚠️ Segment count (increased to accommodate dart points)

### Added Elements

- ➕ Dart points on segments adjacent to inward angles
- ➕ Displaced vertex position for original inward angle

---

## Validation Rules

### Structure Validation

```javascript
function validateStructure(lines) {
  const roomBeginCount = lines.filter(l => l.trim() === 'ROOMBEGIN').length;
  const roomEndCount = lines.filter(l => l.trim() === 'ROOMEND').length;
  
  if (roomBeginCount === 0) {
    throw new GLCError('GLC_MISSING_ROOMBEGIN', 'No room blocks found');
  }
  
  if (roomBeginCount !== roomEndCount) {
    throw new GLCError(
      'GLC_UNBALANCED_ROOMS',
      `Unbalanced room blocks: ${roomBeginCount} ROOMBEGIN, ${roomEndCount} ROOMEND`
    );
  }
  
  return roomBeginCount;
}
```

### Coordinate Validation

```javascript
function parseCoordinate(line) {
  // Expected format: "Key X, Y" or "X, Y"
  const match = line.match(/(-?\d+\.?\d*),\s*(-?\d+\.?\d*)/);
  
  if (!match) {
    throw new GLCError('GLC_INVALID_COORDINATE', `Cannot parse: ${line}`);
  }
  
  const x = parseFloat(match[1]);
  const y = parseFloat(match[2]);
  
  if (isNaN(x) || isNaN(y)) {
    throw new GLCError('GLC_INVALID_COORDINATE', `NaN coordinates: ${line}`);
  }
  
  return { x, y };
}
```

### Point Count Validation

```javascript
function validateContour(points) {
  if (points.length < 3) {
    throw new GLCError(
      'GLC_INSUFFICIENT_POINTS',
      `Contour has ${points.length} points, minimum is 3`
    );
  }
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `GLC_INVALID_ENCODING` | 400 | File not windows-1251 encoded |
| `GLC_MISSING_ROOMBEGIN` | 400 | No ROOMBEGIN block found |
| `GLC_UNBALANCED_ROOMS` | 400 | ROOMBEGIN/ROOMEND count mismatch |
| `GLC_INVALID_COORDINATE` | 400 | Coordinate parse failure |
| `GLC_INSUFFICIENT_POINTS` | 400 | Contour has < 3 points |
| `GLC_PROCESSING_ERROR` | 500 | Dart processing failure |

---

## Example: Valid GLC File

```
RoomName Test Room
UID1 953C8771-99CA-4D40-A98E-FA85C774D591
RoomHeight 2700
WITHOUT_POLOTNO False
WITHOUT_HARPOON False
ROOMBEGIN
RoomName Test Room
AnglePoint 0.00, 0.00
AnglePoint 5000.00, 0.00
AnglePoint 5000.00, 4000.00
AnglePoint 3000.00, 4000.00
AnglePoint 3000.00, 2000.00
AnglePoint 0.00, 2000.00
NPLine 6
STARTPOINT 0
PARAMS2
FirstLineWidth 0.5
FullLineWidth 1.0
StretchParamPer 100
ROOMEND
```

**Note**: This example has one inward angle at point (3000, 2000) - the re-entrant corner.

---

## Example: Processed Output

```
RoomName Test Room
UID1 953C8771-99CA-4D40-A98E-FA85C774D591
RoomHeight 2700
WITHOUT_POLOTNO False
WITHOUT_HARPOON False
ROOMBEGIN
RoomName Test Room
AnglePoint 0.00, 0.00
AnglePoint 5000.00, 0.00
AnglePoint 5000.00, 4000.00
AnglePoint 3000.00, 4000.00
AnglePoint 3000.00, 2100.00    ; Dart point on next segment
AnglePoint 2980.00, 1980.00    ; Displaced vertex
AnglePoint 2900.00, 2000.00    ; Dart point on prev segment
AnglePoint 0.00, 2000.00
NPLine 8
STARTPOINT 0
PARAMS2
FirstLineWidth 0.5
FullLineWidth 1.0
StretchParamPer 100
ROOMEND
```

**Changes**:
- Original 6 points → 8 points (2 dart points + 1 displaced vertex - 1 original)
- Point labels renumbered A→H clockwise
- Inward angle vertex displaced to create dart cut

---

## Compliance Checklist

For a GLC file to be considered valid for dart processing:

- [ ] Windows-1251 encoding (no BOM)
- [ ] CRLF line endings
- [ ] At least one ROOMBEGIN/ROOMEND pair
- [ ] Balanced ROOMBEGIN/ROOMEND counts
- [ ] At least 3 points per contour
- [ ] Valid coordinate format (X, Y with decimal dot)
- [ ] Clockwise point ordering
