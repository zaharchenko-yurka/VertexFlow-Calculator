# Contract: glcDartProcessor Module API

**Feature**: 1-glc-dart-processing  
**Date**: 2026-03-10  
**Purpose**: Define public API contract for glcDartProcessor module

---

## Module Overview

**Module Path**: `assets/js/glcDartProcessor.js`

**Purpose**: Process GLC ceiling contour files to add dart cuts at inward-pointing angles.

**Design Principles**:
- Single responsibility (Constitution Principle V)
- Pure functions where possible
- JSDoc type annotations
- Independently testable

---

## Exports

```javascript
export {
  // Main processing
  processDarts,
  
  // Validation
  validateGLC,
  
  // Utilities
  generateReport,
  formatError,
  
  // Constants
  MIN_SEGMENT_LENGTH,
  STANDARD_DART_DISTANCE,
  EXTENSION_DISTANCE,
  ANGLE_TOLERANCE
};
```

---

## Function: processDarts

### Signature

```javascript
/**
 * Process a GLC file to add dart cuts at inward-pointing angles.
 * 
 * @param {ArrayBuffer} arrayBuffer - Raw GLC file data
 * @param {string} inputFilename - Original filename (for output naming)
 * @returns {Promise<ProcessResult>} Processing result with output file and report
 * @throws {GLCError} On validation or processing failure
 */
export async function processDarts(arrayBuffer, inputFilename) {
  // Implementation
}
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `arrayBuffer` | ArrayBuffer | Yes | Raw GLC file bytes |
| `inputFilename` | string | Yes | Original filename |

### Returns

**Type**: `Promise<ProcessResult>`

```javascript
/**
 * @typedef {Object} ProcessResult
 * @property {Blob} output - Processed GLC file as Blob
 * @property {string} outputFilename - Output filename with "-processed" suffix
 * @property {ProcessingReport} report - Processing summary
 * @property {boolean} success - true if processing completed successfully
 */
```

### Throws

**Type**: `GLCError`

```javascript
/**
 * @typedef {Object} GLCError
 * @property {string} code - Error code (e.g., 'GLC_INVALID_STRUCTURE')
 * @property {string} message - User-friendly error message
 * @property {string} details - Technical details for debugging
 * @property {number} [line] - Line number if applicable
 */
```

### Example

```javascript
import { processDarts } from './glcDartProcessor.js';

const file = fileInput.files[0];
const arrayBuffer = await file.arrayBuffer();

try {
  const result = await processDarts(arrayBuffer, file.name);
  
  if (result.success) {
    downloadFile(result.output, result.outputFilename);
    displayReport(result.report);
  }
} catch (error) {
  displayError(error);
}
```

---

## Function: validateGLC

### Signature

```javascript
/**
 * Validate GLC file structure without processing.
 * 
 * @param {ArrayBuffer} arrayBuffer - Raw GLC file data
 * @returns {Promise<ValidationResult>} Validation result
 */
export async function validateGLC(arrayBuffer) {
  // Implementation
}
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `arrayBuffer` | ArrayBuffer | Yes | Raw GLC file bytes |

### Returns

**Type**: `Promise<ValidationResult>`

```javascript
/**
 * @typedef {Object} ValidationResult
 * @property {boolean} valid - true if file is valid GLC format
 * @property {GLCError[]} errors - Array of validation errors
 * @property {string[]} warnings - Array of non-fatal warnings
 * @property {number} contourCount - Number of room contours found
 */
```

### Example

```javascript
import { validateGLC } from './glcDartProcessor.js';

const validation = await validateGLC(arrayBuffer);

if (!validation.valid) {
  validation.errors.forEach(err => {
    console.error(`[${err.code}] ${err.message}`);
  });
  return false;
}

console.log(`Valid GLC with ${validation.contourCount} contours`);
return true;
```

---

## Function: generateReport

### Signature

```javascript
/**
 * Generate a human-readable processing report.
 * 
 * @param {ProcessResult} result - Result from processDarts
 * @returns {string} Formatted report text
 */
export function generateReport(result) {
  // Implementation
}
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `result` | ProcessResult | Yes | Result from processDarts |

### Returns

**Type**: `string`

### Example Output

```
Processing Report
=================

Contours found: 3
Processed contours: 2
Total inward angles: 5
Darts created: 5
Darts skipped: 1

Per-Contour Details:
--------------------
Contour 1 (Living Room):
  Inward angles: 2
  Darts created: 2
  Darts skipped: 0

Contour 2 (Kitchen):
  Inward angles: 3
  Darts created: 3
  Darts skipped: 0

Contour 3 (Bedroom):
  Inward angles: 0
  Darts created: 0
  Darts skipped: 0
  Note: No inward angles found

Skipped Angles:
---------------
- Contour 2, Angle 3: Skipped - adjacent segment < 50mm (32mm)
```

---

## Function: formatError

### Signature

```javascript
/**
 * Format a GLCError for display.
 * 
 * @param {GLCError} error - Error to format
 * @param {boolean} includeDetails - Whether to include technical details
 * @returns {string} Formatted error message
 */
export function formatError(error, includeDetails = false) {
  // Implementation
}
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `error` | GLCError | Yes | Error to format |
| `includeDetails` | boolean | No | Include technical details (default: false) |

### Returns

**Type**: `string`

### Example

```javascript
import { formatError } from './glcDartProcessor.js';

const error = new GLCError(
  'GLC_INVALID_STRUCTURE',
  'Missing room data',
  'Expected ROOMBEGIN at line 1, found EOF',
  1
);

console.log(formatError(error));
// Output: "Invalid GLC file: Missing room data"

console.log(formatError(error, true));
// Output: "Invalid GLC file: Missing room data [GLC_INVALID_STRUCTURE]
//          Expected ROOMBEGIN at line 1, found EOF"
```

---

## Constants

> **Note**: All magic numbers are centralized in the constants configuration file.
> See [`../constants.md`](../constants.md) for complete documentation with Ukrainian comments.

```javascript
/**
 * Minimum segment length for dart processing (mm).
 * Segments shorter than this cause the angle to be skipped.
 * @type {number}
 * @see {@link ../constants.md|Constants: MIN_SEGMENT_LENGTH}
 */
export const MIN_SEGMENT_LENGTH = 50;

/**
 * Standard dart point distance from angle vertex (mm).
 * Used when both adjacent segments are >= 120mm.
 * @type {number}
 * @see {@link ../constants.md|Constants: STANDARD_DART_DISTANCE}
 */
export const STANDARD_DART_DISTANCE = 100;

/**
 * Threshold for short segment handling (mm).
 * Segments shorter than this use full length instead of standard distance.
 * @type {number}
 * @see {@link ../constants.md|Constants: SHORT_SEGMENT_THRESHOLD}
 */
export const SHORT_SEGMENT_THRESHOLD = 120;

/**
 * Standard segment extension distance (mm).
 * Used when new segment length >= 100mm.
 * @type {number}
 * @see {@link ../constants.md|Constants: EXTENSION_DISTANCE}
 */
export const EXTENSION_DISTANCE = 20;

/**
 * Percentage extension for short segments.
 * Used when new segment length < 100mm.
 * @type {number}
 * @see {@link ../constants.md|Constants: EXTENSION_PERCENTAGE}
 */
export const EXTENSION_PERCENTAGE = 0.10;

/**
 * Angle tolerance for 180° comparison (degrees).
 * Accounts for floating point precision errors.
 * @type {number}
 * @see {@link ../constants.md|Constants: ANGLE_TOLERANCE}
 */
export const ANGLE_TOLERANCE = 0.5;

/**
 * Threshold for close inward angles (mm).
 * Angles closer than this receive special split-segment handling.
 * @type {number}
 * @see {@link ../constants.md|Constants: CLOSE_ANGLE_THRESHOLD}
 */
export const CLOSE_ANGLE_THRESHOLD = 220;

// Additional constants (see constants.md for full list)
export const ANGLE_THRESHOLD = 180.0;
export const INWARD_ANGLE_THRESHOLD = 180.5;
export const EXTENSION_THRESHOLD = 100;
export const MIN_CONTOUR_POINTS = 3;
export const FILE_ENCODING = 'windows-1251';
export const LINE_ENDING = '\r\n';
export const OUTPUT_FILENAME_SUFFIX = '-processed';
```

---

## Type Definitions

```javascript
/**
 * @typedef {Object} Point
 * @property {number} x - X coordinate in millimeters
 * @property {number} y - Y coordinate in millimeters
 * @property {string} label - Alphabetical label (A, B, C, ...)
 * @property {boolean} isOriginal - True if from original contour
 * @property {boolean} isInwardAngle - True if this is an inward-pointing angle
 */

/**
 * @typedef {Object} Segment
 * @property {Point} start - Starting vertex
 * @property {Point} end - Ending vertex
 * @property {number} length - Euclidean distance in millimeters
 */

/**
 * @typedef {Object} InwardAngle
 * @property {Point} vertex - The inward angle vertex
 * @property {Segment} prevSegment - Segment approaching the vertex
 * @property {Segment} nextSegment - Segment leaving the vertex
 * @property {number} angle - Interior angle in degrees (>180°)
 * @property {string|null} skipReason - Reason for skipping, if not processed
 */

/**
 * @typedef {Object} DartCut
 * @property {InwardAngle} inwardAngle - Reference to processed inward angle
 * @property {Point} prevDartPoint - Dart point on previous segment
 * @property {Point} nextDartPoint - Dart point on next segment
 * @property {Point} displacedVertex - New position of original vertex
 * @property {number} prevExtension - Extension distance for prev segment
 * @property {number} nextExtension - Extension distance for next segment
 */

/**
 * @typedef {Object} ContourReport
 * @property {string} contourId - Contour identifier
 * @property {number} inwardAnglesFound - Count of inward angles detected
 * @property {number} dartsCreated - Count of dart cuts added
 * @property {number} dartsSkipped - Count of angles skipped
 * @property {string[]} skipReasons - Reasons for skipping
 */

/**
 * @typedef {Object} ProcessingReport
 * @property {number} totalContours - Count of contours in file
 * @property {number} processedContours - Count with at least one dart
 * @property {number} totalInwardAngles - Total inward angles found
 * @property {number} processedAngles - Total angles that received darts
 * @property {number} skippedAngles - Total angles skipped
 * @property {ContourReport[]} contourDetails - Per-contour breakdown
 */
```

---

## Error Codes Reference

| Code | Message | Cause |
|------|---------|-------|
| `GLC_INVALID_ENCODING` | "Invalid file encoding" | File not windows-1251 |
| `GLC_MISSING_ROOMBEGIN` | "Missing room data in file" | No ROOMBEGIN found |
| `GLC_UNBALANCED_ROOMS` | "Unbalanced room blocks" | ROOMBEGIN ≠ ROOMEND |
| `GLC_INVALID_COORDINATE` | "Invalid coordinate format" | Parse failure |
| `GLC_INSUFFICIENT_POINTS` | "Invalid contour geometry" | < 3 points |
| `GLC_PROCESSING_ERROR` | "Processing failed" | Dart processing error |

---

## Implementation Checklist

Module must satisfy:

- [ ] Export all functions listed in Exports section
- [ ] All functions have JSDoc type annotations
- [ ] All functions are pure (no side effects except I/O)
- [ ] Error handling returns structured GLCError objects
- [ ] Constants exported for all magic numbers
- [ ] Module is ES6 module format (import/export)
- [ ] No external dependencies (vanilla JavaScript only)
- [ ] Compatible with existing app.js module loading

---

## Testing Contract

Module must pass:

```javascript
import { processDarts, validateGLC, MIN_SEGMENT_LENGTH } from './glcDartProcessor.js';

// Test 1: Valid file processing
const result = await processDarts(validGlcBuffer, 'test.glc');
assert(result.success === true);
assert(result.output instanceof Blob);
assert(result.outputFilename.endsWith('-processed.glc'));

// Test 2: Invalid file rejection
try {
  await processDarts(invalidGlcBuffer, 'bad.glc');
  assert.fail('Should have thrown');
} catch (error) {
  assert(error.code === 'GLC_INVALID_STRUCTURE');
}

// Test 3: Validation
const validation = await validateGLC(validGlcBuffer);
assert(validation.valid === true);
assert(validation.errors.length === 0);

// Test 4: Constants exported
assert(MIN_SEGMENT_LENGTH === 50);
```
