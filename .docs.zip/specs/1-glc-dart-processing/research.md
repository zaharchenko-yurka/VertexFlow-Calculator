# Research: GLC Dart Processing

**Feature**: 1-glc-dart-processing  
**Date**: 2026-03-10  
**Purpose**: Resolve technical unknowns for dart processing implementation

---

## Geometric Algorithms

### Decision: Signed angle calculation with cross-product method

**Rationale**: 
- GLC format uses clockwise point ordering (per constitution Technical Architecture)
- Cross-product of consecutive edge vectors cleanly determines angle direction
- For vectors AB and BC: cross = (B.x-A.x)*(C.y-B.y) - (B.y-A.y)*(C.x-B.x)
- Negative cross-product indicates right turn (inward angle in clockwise contour)
- Angle magnitude computed via dot product: cos(θ) = (AB·BC) / (|AB|×|BC|)
- Inward angles identified when: cross < 0 AND θ > 180° (or signed angle < 0)

**Alternatives Considered**:
- Interior angle sum method: More complex, requires polygon orientation detection first
- Winding number approach: Overkill for simple convex/concave vertex detection
- Ray casting: Unnecessary complexity when cross-product suffices

**Implementation Notes**:
- Apply ±0.5° tolerance for floating point comparison at 180° threshold
- Handle collinear points (cross ≈ 0) as non-angles (180° exactly)

---

### Decision: Bisector-based dart vertex displacement

**Rationale**:
- Dart cut requires displacing original inward vertex along angle bisector
- Bisector direction: normalize(AB/|AB| + BC/|BC|) where B is the inward vertex
- Displacement distance computed from extension geometry (20mm or 10%)
- Ensures symmetric dart cut regardless of adjacent segment length asymmetry

**Alternatives Considered**:
- Perpendicular to one segment: Would create asymmetric darts
- Fixed offset direction: Would not follow contour geometry naturally
- User-specified displacement: Adds complexity without value

**Implementation Notes**:
- For segments <100mm, use 10% extension (per FR-008)
- Ensure displacement moves vertex inward (toward contour interior)

---

### Decision: Single-pass processing with no recursion

**Rationale**:
- Per spec requirement (FR-011): process each contour exactly once
- Newly created dart points are NOT re-evaluated as potential inward angles
- Prevents infinite recursion in complex geometries
- Matches physical manufacturing intent (darts are terminal modifications)

**Alternatives Considered**:
- Recursive processing: Would create nested darts, not physically meaningful
- Multi-pass until stable: Unnecessary complexity, no user value
- Iterative with depth limit: Still solves wrong problem

**Implementation Notes**:
- Mark original vertices vs. dart points during processing
- Only evaluate original contour vertices for inward angle detection

---

## GLC Format Handling

### Decision: Windows-1251 encoding with explicit conversion

**Rationale**:
- GLC format specification requires windows-1251 (Cyrillic) encoding without BOM
- JavaScript strings are UTF-16 internally; must convert on read/write
- Browser TextEncoder/TextDecoder API supports windows-1251 via encoding parameter
- Preserves Cyrillic room names, material specs, and comments

**Alternatives Considered**:
- UTF-8 throughout: Would break compatibility with existing GLC tools
- Binary ArrayBuffer manual conversion: Overly complex, error-prone
- Server-side conversion: Violates Constitution Principle I (Client-Side First)

**Implementation Notes**:
- Use `new TextDecoder('windows-1251')` for file input
- Use `new TextEncoder('windows-1251')` for file output (if browser supports)
- Fallback: Manual byte mapping table if encoding parameter unsupported

---

### Decision: CRLF line ending normalization

**Rationale**:
- GLC specification requires CRLF (`\r\n`) line endings
- Browser file input may normalize to LF (`\n`) on some platforms
- Must preserve original line endings on read, restore on write
- Ensures output files are byte-compatible with GLC consumers

**Alternatives Considered**:
- Accept any line ending on input: Risk of inconsistent parsing
- Output LF only: Breaks GLC format compliance
- Platform-native line endings: Violates GLC specification

**Implementation Notes**:
- Split on `/\r?\n/` for flexible input parsing
- Join with `\r\n` for output generation
- Preserve trailing newline if present in input

---

### Decision: ROOMBEGIN/ROOMEND block validation

**Rationale**:
- GLC format uses explicit ROOMBEGIN/ROOMEND delimiters for room blocks
- Valid GLC file must have at least one complete room block
- Missing or mismatched delimiters indicate corrupted/invalid file
- Early validation prevents cascading parse errors

**Alternatives Considered**:
- Lenient parsing (assume implicit blocks): Risk of silent data corruption
- Line-by-line processing without validation: Cannot detect structural errors
- Schema validation against full GLC spec: Overly strict for dart processing use case

**Implementation Notes**:
- Validate: count(ROOMBEGIN) == count(ROOMEND) >= 1
- Validate: ROOMBEGIN appears before ROOMEND in file order
- Error code: `GLC_INVALID_STRUCTURE: Missing ROOMBEGIN at line {N}`

---

## Point Renaming Algorithm

### Decision: Clockwise alphabetical renaming with preserved start point

**Rationale**:
- Per spec (FR-010): rename points A, B, C... in clockwise order
- Starting point: first point in original contour (preserves orientation reference)
- Dart points inserted between original points receive interpolated labels (A1, B1, etc.) OR renumbered sequentially after all insertions
- Sequential renumbering preferred: simpler, matches GLC convention

**Alternatives Considered**:
- Lowest-Y point as start: Adds complexity, no user value
- Counter-clockwise ordering: Violates GLC clockwise convention
- Preserve original labels: Cannot accommodate new dart points

**Implementation Notes**:
- After all dart points added, renumber ALL points sequentially: A, B, C, D...
- Use ASCII uppercase letters (A-Z), then AA, AB, AC... if >26 points
- Update all references to points in downstream GLC blocks (VIREZS, ZONES, etc.)

---

## File I/O Patterns

### Decision: FileReader + Blob download for file processing

**Rationale**:
- FileReader API: Read uploaded GLC file as ArrayBuffer
- Blob API: Create downloadable GLC file from processed output
- Standard browser pattern, no dependencies
- Supports files up to browser memory limits (typically >100MB)

**Alternatives Considered**:
- Fetch API with object URLs: Unnecessary indirection for local files
- File System Access API: Better UX but limited browser support
- Base64 data URLs: Memory inefficient for large files

**Implementation Notes**:
- `fileReader.readAsArrayBuffer(file)` for input
- `URL.createObjectURL(new Blob([data], {type: 'application/octet-stream'}))` for output
- Revoke object URL after download to prevent memory leaks

---

## Performance Considerations

### Decision: Synchronous processing for typical file sizes

**Rationale**:
- Target: 100 contours in <5 seconds (SC-001)
- Typical ceiling files: 10-50 contours, 100-500 points total
- Geometric calculations are O(n) per contour where n = point count
- Modern JavaScript engines handle ~10M operations/second
- Estimated processing time: 100-500ms for typical files

**Alternatives Considered**:
- Web Worker for background processing: Adds complexity, unnecessary for target performance
- Async/await with chunking: No benefit for CPU-bound work under 1 second
- Progressive rendering: Only needed for visual feedback on >10 second operations

**Implementation Notes**:
- Profile with real GLC files from `.docs/GLC_FORMAL_SPECIFICATION/` samples
- Add progress indicator only if processing exceeds 1 second
- Avoid DOM manipulation during processing loop

---

## Error Handling Strategy

### Decision: Structured error codes with user-friendly messages

**Rationale**:
- Per clarification: strict validation with technical error codes
- Error format: `{code: 'GLC_XXX', message: 'User-friendly text', details: 'Technical info'}`
- Display technical details in expandable panel for advanced users
- Log full error details to console for debugging

**Alternatives Considered**:
- Throw generic Error objects: Loses structured error information
- Silent failure with empty output: User cannot diagnose problems
- Alert dialogs: Disruptive, poor UX for professional users

**Implementation Notes**:
- Define error codes: `GLC_INVALID_ENCODING`, `GLC_MISSING_ROOMBEGIN`, `GLC_INVALID_COORDINATE`, etc.
- Map to user messages: "Invalid GLC file: missing room block" + details: "Expected ROOMBEGIN at line 1"
- Display in inline error panel (matches FR-013 success panel pattern)

---

## Summary of Resolved Unknowns

| Category | Unknown | Resolution |
|----------|---------|------------|
| Geometric Algorithms | Angle direction detection | Signed angle with cross-product |
| Geometric Algorithms | Dart vertex displacement | Bisector-based displacement |
| Geometric Algorithms | Recursion handling | Single-pass, no recursion |
| GLC Format | Encoding conversion | TextEncoder/TextDecoder windows-1251 |
| GLC Format | Line ending handling | Normalize to CRLF on output |
| GLC Format | Structure validation | ROOMBEGIN/ROOMEND count matching |
| Point Renaming | Label assignment strategy | Sequential alphabetical after insertions |
| File I/O | Browser API selection | FileReader + Blob download |
| Performance | Processing strategy | Synchronous for typical file sizes |
| Error Handling | Error reporting format | Structured codes with expandable details |

**All NEEDS CLARIFICATION items from Technical Context resolved.**
