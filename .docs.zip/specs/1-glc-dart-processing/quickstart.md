# Quickstart: GLC Dart Processor (Client-side)

This quickstart shows how to use the `glc-dart-processor` module in-browser and via the bundled WordPress integration.

Usage (browser integration)

1. Load the existing converter UI page in your browser. Open the "DXF to GLC Converter" panel.
2. Convert or upload a `.glc` file using the UI `Convert` flow to produce a GLC in the UI.
3. Click `Process Darts` to run the dart processing algorithm on the currently loaded GLC.
4. Review the inline report panel for per-contour summaries and any skipped angles.
5. Click `Download GLC` to save the processed file. The file will be encoded using `windows-1251` when supported; otherwise a UTF-8 fallback is used.

Programmatic usage (ES6)

```js
import { validateGLC, processDarts, buildGLC, encodeOutput } from 'glcDartProcessor.js';

// Given `glcText` from FileReader or fetch
const { valid, errors, glc } = validateGLC(glcText);
if (!valid) throw new Error(errors);
const processed = processDarts(glc);
const outText = buildGLC(processed);
const { bytes, encoding } = encodeOutput(outText, 'windows-1251');
// Create blob and trigger download
```

Notes
- The module performs single-pass processing: newly created dart points are not re-evaluated for additional darts.
- Metadata blocks and unrecognized blocks are preserved verbatim; mapping references inside other blocks (e.g., point name references) is a separate task.
- For bulk testing, use your repository's `.docs/GLC_FORMAL_SPECIFICATION/` sample files.
# Quickstart: GLC Dart Processing Module

**Feature**: 1-glc-dart-processing  
**Date**: 2026-03-10  
**Purpose**: Getting started guide for glcDartProcessor module

---

## Overview

The `glcDartProcessor` module processes GLC ceiling contour files to add dart cuts (вытачки) at inward-pointing angles, reducing wrinkle risk during stretch ceiling installation on shadow/floating profiles.

**Key Capabilities**:
- Identifies inward angles (>180°) in clockwise contours
- Adds dart points at 100mm from angle vertex (with edge case handling)
- Extends dart segments by 20mm (or 10% for short segments)
- Displaces original vertex along angle bisector
- Renames all points alphabetically in clockwise order
- Preserves GLC format (windows-1251, CRLF, metadata)

**Configuration**: All magic numbers are centralized in [`constants.md`](constants.md) with detailed Ukrainian comments explaining each parameter.

---

## Installation

The module is part of this project. No additional installation required. See the design system at `specs/design-system.json`.

**File Location**:
```
assets/js/glcDartProcessor.js
```

**Module Import** (in app.js or other modules):
```javascript
import { processDarts, validateGLC, generateReport } from './glcDartProcessor.js';
```

---

## Basic Usage

### Process a GLC File

```javascript
import { processDarts } from './glcDartProcessor.js';

// Handle file upload
const fileInput = document.getElementById('glc-upload');
fileInput.addEventListener('change', async (event) => {
  const file = event.target.files[0];
  
  if (!file) return;
  
  try {
    // Read file as ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();
    
    // Process the GLC file
    const result = await processDarts(arrayBuffer, file.name);
    
    // Download processed file
    downloadFile(result.output, result.outputFilename);
    
    // Display report
    displayReport(result.report);
    
  } catch (error) {
    displayError(error);
  }
});

function downloadFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
```

### Expected Input/Output

**Input**: `room1.glc` (GLC file with inward angles)

**Output**: `room1-processed.glc` (GLC file with dart cuts added)

**Report**:
```
Contours found: 3
Processed angles: 5
Skipped angles: 1

Contour 1: 2 darts created
Contour 2: 3 darts created, 1 skipped (< 50mm segment)
Contour 3: 0 darts (no inward angles)
```

---

## API Reference

### `processDarts(arrayBuffer, inputFilename)`

Process a GLC file and return the modified output.

**Parameters**:
- `arrayBuffer`: `ArrayBuffer` - Raw GLC file data
- `inputFilename`: `string` - Original filename (for output naming)

**Returns**: `Promise<ProcessResult>`

**ProcessResult**:
```typescript
interface ProcessResult {
  output: Blob;              // Processed GLC file as Blob
  outputFilename: string;    // Output filename with "-processed" suffix
  report: ProcessingReport;  // Processing summary
  success: boolean;          // true if processing completed
}
```

**Throws**: `GLCError` on validation failure

---

### `validateGLC(arrayBuffer)`

Validate GLC file structure without processing.

**Parameters**:
- `arrayBuffer`: `ArrayBuffer` - Raw GLC file data

**Returns**: `Promise<ValidationResult>`

**ValidationResult**:
```typescript
interface ValidationResult {
  valid: boolean;
  errors: GLCError[];
  warnings: string[];
  contourCount: number;
}
```

**Example**:
```javascript
import { validateGLC } from './glcDartProcessor.js';

const validation = await validateGLC(arrayBuffer);

if (!validation.valid) {
  validation.errors.forEach(err => {
    console.error(`[${err.code}] ${err.message}`);
  });
  return;
}

console.log(`Valid GLC file with ${validation.contourCount} contours`);
```

---

### `generateReport(processResult)`

Generate a human-readable processing report.

**Parameters**:
- `processResult`: `ProcessResult` - Result from `processDarts`

**Returns**: `string` - Formatted report text

**Example**:
```javascript
import { processDarts, generateReport } from './glcDartProcessor.js';

const result = await processDarts(arrayBuffer, 'room.glc');
const reportText = generateReport(result);

// Display in inline panel
document.getElementById('report-panel').innerHTML = `
  <details open>
    <summary>Processing Report</summary>
    <pre>${reportText}</pre>
  </details>
`;
```

---

## Error Handling

### GLCError Structure

```typescript
interface GLCError {
  code: string;      // e.g., 'GLC_INVALID_STRUCTURE'
  message: string;   // User-friendly message
  details: string;   // Technical details for debugging
  line?: number;     // Line number if applicable
}
```

### Error Codes

| Code | Description | User Message |
|------|-------------|--------------|
| `GLC_INVALID_ENCODING` | File is not windows-1251 encoded | "Invalid file encoding" |
| `GLC_MISSING_ROOMBEGIN` | No ROOMBEGIN block found | "Missing room data in file" |
| `GLC_INVALID_COORDINATE` | Coordinate parse failure | "Invalid coordinate format" |
| `GLC_INSUFFICIENT_POINTS` | Contour has < 3 points | "Invalid contour geometry" |
| `GLC_PROCESSING_ERROR` | Dart processing failure | "Processing failed" |

### Error Display Example

```javascript
try {
  const result = await processDarts(arrayBuffer, filename);
  // ... handle success
} catch (error) {
  if (error.code) {
    // Structured GLCError
    showErrorPanel({
      title: 'Processing Failed',
      message: error.message,
      details: error.details,
      code: error.code
    });
  } else {
    // Unexpected error
    showErrorPanel({
      title: 'Unexpected Error',
      message: 'An unexpected error occurred',
      details: error.toString()
    });
  }
}

function showErrorPanel(error) {
  const panel = document.getElementById('error-panel');
  panel.innerHTML = `
    <div class="error-panel">
      <h3>${error.title}</h3>
      <p>${error.message}</p>
      <details>
        <summary>Technical Details</summary>
        <pre>${error.details}</pre>
        <code>Error Code: ${error.code}</code>
      </details>
    </div>
  `;
  panel.classList.remove('hidden');
}
```

---

## Processing Rules Reference

### Dart Point Placement

| Condition | Dart Distance |
|-----------|---------------|
| Standard (both segments ≥ 120mm) | 100mm on both segments |
| One segment < 120mm | Full segment length on short side, 100mm on long side |
| Both segments < 120mm | Use shorter segment length for both |
| Either segment < 50mm | Skip this angle (do not process) |
| Two inward angles ≤ 220mm apart | Split connecting segment in half, use half-length |

### Segment Extension

| New Segment Length | Extension |
|-------------------|-----------|
| ≥ 100mm | +20mm |
| < 100mm | +10% of length |

### Angle Detection

- **Inward Angle**: > 180.5° (accounts for ±0.5° tolerance)
- **Calculation**: Signed angle with clockwise traversal
- **Method**: Cross-product of consecutive edge vectors

---

## Integration with Existing Modules

### Module Dependencies

```
glcDartProcessor.js
├── (no external dependencies - vanilla JS)
└── Uses built-in APIs:
    ├── TextDecoder / TextEncoder (encoding)
    ├── FileReader (file input)
    └── Blob / URL (file output)
```

### Integration Points

**app.js** (main entry point):
```javascript
import { processDarts } from './glcDartProcessor.js';

// Existing DXF → GLC flow
async function handleDxfUpload(dxfFile) {
  const glcResult = await convertDxfToGlc(dxfFile);
  // ... render preview
}

// NEW: GLC dart processing flow
async function handleGlcUpload(glcFile) {
  const result = await processDarts(glcFile.arrayBuffer(), glcFile.name);
  downloadFile(result.output, result.outputFilename);
  displayReport(result.report);
}
```

**glcBuilder.js** (existing GLC generation):
- No changes required
- `glcDartProcessor` operates on GLC output from `glcBuilder`

---

## Testing

### Manual Test Files

Test files located in `.docs/GLC_FORMAL_SPECIFICATION/`:

1. **Simple contour**: Single room with 1 inward angle
2. **Multi-room**: Multiple contours with varying inward angles
3. **Edge cases**: Short segments, close angles, no inward angles
4. **Invalid files**: Missing ROOMBEGIN, bad encoding, etc.

### Test Checklist

- [ ] Upload valid GLC with 1 inward angle → Verify 1 dart created
- [ ] Upload valid GLC with multiple contours → Verify all processed
- [ ] Upload GLC with no inward angles → Verify unchanged output
- [ ] Upload invalid GLC → Verify error with technical code
- [ ] Upload GLC with < 50mm segment → Verify angle skipped
- [ ] Re-import processed GLC → Verify no errors
- [ ] Check output encoding → Verify windows-1251
- [ ] Check output line endings → Verify CRLF
- [ ] Check point labels → Verify alphabetical clockwise order

---

## Performance Guidelines

### Expected Performance

| File Size | Contours | Points | Expected Time |
|-----------|----------|--------|---------------|
| Small | 1-10 | 10-50 | < 100ms |
| Medium | 10-50 | 50-200 | < 500ms |
| Large | 50-100 | 200-500 | < 2s |
| Very Large | 100+ | 500+ | < 5s (SC-001) |

### Optimization Tips

1. **Avoid DOM manipulation during processing** - Batch UI updates
2. **Use typed arrays for coordinate math** - `Float64Array` for precision
3. **Minimize object allocations** - Reuse segment objects where possible
4. **Profile with real files** - Use sample GLC files from spec

---

## Troubleshooting

### Common Issues

**Issue**: "Invalid file encoding" error  
**Cause**: File saved as UTF-8 instead of windows-1251  
**Solution**: Re-export GLC from source application with correct encoding

**Issue**: "Missing room data" error  
**Cause**: GLC file missing ROOMBEGIN/ROOMEND blocks  
**Solution**: Verify file was exported correctly from CAD system

**Issue**: No darts created  
**Cause**: Contour has no inward angles (all ≤ 180°)  
**Solution**: This is expected behavior; check contour geometry

**Issue**: Some angles skipped  
**Cause**: Adjacent segments < 50mm  
**Solution**: Expected behavior per FR-004; noted in report

---

## Next Steps

After integrating this module:

1. Test with sample GLC files from `.docs/GLC_FORMAL_SPECIFICATION/`
2. Integrate Process button into UI (per FR-017)
3. Add inline report panel (per FR-013)
4. Implement error display panel
5. Add file download functionality

For task breakdown, see `tasks.md`.
