# Manual Test Checklist: GLC Dart Processing

Run these tests manually using real GLC files (samples recommended in `.docs/GLC_FORMAL_SPECIFICATION/`).

- [ ] Basic round-trip: convert a simple single-contour GLC → Process Darts → Download → Re-open in calculator
- [ ] Standard inward angle: GLC with known inward angles → verify darts added at ~100mm on both sides
- [ ] Short-segment handling: test cases with segments 30mm, 80mm, 150mm
- [ ] Close-angle handling: two inward angles spaced 150..220mm → verify split placement
- [ ] Metadata preservation: verify `RoomName`, `UID1`, `PARAMS2`, `ESTIME` blocks preserved
- [ ] Encoding verification: processed file encoded as `windows-1251` and imports without corruption
- [ ] Multi-room file: ensure each room renames points independently (A..Z per room)
- [ ] Error handling: feed malformed GLC (missing ROOMEND) and confirm user-friendly error
