# Feature Specification: GLC Dart Processing for Internal Angles

**Feature Branch**: `1-glc-dart-processing`
**Created**: 2026-03-10
**Status**: Draft
**Input**: Client-side GLC contour processing for internal angle dart creation

## Clarifications

### Session 2026-03-10

- Q: How should the system respond when encountering invalid or problematic input files? → A: Strict validation: Reject invalid GLC files immediately with technical error codes
- Q: How should the processing summary be presented to the user? → A: Inline panel showing per-contour breakdown with expandable details
- Q: How should the system determine if an angle is inward-pointing? → A: Signed angle with clockwise traversal: inward angles produce negative signed angles or angles >180°
- Q: When should dart processing begin? → A: Explicit process button: User reviews upload, then clicks "Process" to start
- Q: How should the processed file be named? → A: Original name with suffix: Append "-processed" or "-darts" to original filename

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Process GLC File with Internal Angle Darts (Priority: P1)

A professional stretch ceiling installer uploads a GLC file containing ceiling contours, reviews the upload, then clicks a "Process" button to start dart processing. The system automatically identifies all inward-pointing angles (greater than 180°) and creates dart cuts (вытачки) to reduce wrinkle risk during installation on shadow or floating profiles. After processing, the user downloads the modified GLC file and sees a summary displayed in an inline panel showing per-contour breakdown with expandable details.

**Why this priority**: This is the core value proposition of the feature. Without this capability, installers face wrinkle formation risks when mounting ceilings on shadow/floating profiles in rooms with inward corners.

**Independent Test**: Upload a GLC file with known inward angles → Click Process button → Download processed file → Verify dart points were added at correct positions → Verify inline panel shows accurate per-contour counts with expandable details.

**Acceptance Scenarios**:

1. **Given** a GLC file with one contour containing a single 270° inward corner, **When** the user processes the file, **Then** the output file contains additional points creating a dart at that corner, and the report shows "1 contour, 1 processed angle"
2. **Given** a GLC file with multiple contours each having inward angles, **When** the user processes the file, **Then** all contours are processed independently and the report lists counts per contour
3. **Given** a GLC file with no inward angles (all angles ≤180°), **When** the user processes the file, **Then** the output file is unchanged and the report shows "0 processed angles"

---

### User Story 2 - Handle Short Segment Edge Cases (Priority: P2)

When processing inward angles, the system correctly handles edge cases where adjacent segments are too short for standard dart creation. Segments shorter than 50mm are skipped entirely, segments between 50-120mm receive modified dart placement, and very close inward angles (≤220mm apart) receive special split-segment treatment.

**Why this priority**: Real-world ceiling geometries often have short segments near corners. Incorrect handling would produce invalid cutting patterns that cannot be manufactured.

**Independent Test**: Upload GLC files with specifically crafted short segments (30mm, 80mm, 150mm) → Verify each edge case is handled according to rules → Verify no crashes or invalid output.

**Acceptance Scenarios**:

1. **Given** an inward angle with one adjacent segment of 30mm, **When** processed, **Then** this angle is skipped and noted in output
2. **Given** an inward angle with one segment of 80mm and another of 200mm, **When** processed, **Then** the dart point on the 80mm segment is placed at 80mm (full length) while the other is at standard 100mm
3. **Given** two inward angles spaced 200mm apart, **When** processed, **Then** the segment between them is split in half with dart points at the midpoint distance

---

### User Story 3 - Preserve GLC Format Integrity (Priority: P3)

The processed output maintains full GLC format compatibility, including proper point renaming in alphabetical clockwise order, preserved metadata, and valid file structure that can be re-imported or used in downstream manufacturing systems.

**Why this priority**: GLC is the industry standard format. Output that cannot be read by other systems in the workflow is useless to professional users.

**Independent Test**: Process a GLC file → Import the output into a GLC-compatible viewer or the original system → Verify geometry displays correctly → Verify all metadata is preserved.

**Acceptance Scenarios**:

1. **Given** a valid GLC file with room metadata, **When** processed, **Then** all original metadata (room names, dates, UIDs) is preserved in output
2. **Given** a processed GLC file, **When** re-imported into the calculator, **Then** all points are labeled alphabetically (A, B, C...) in clockwise order starting from the first point
3. **Given** a multi-room GLC file, **When** processed, **Then** each room's points are renamed independently following the same alphabetical clockwise convention

---

### Edge Cases

- What happens when a contour has zero inward angles? System outputs unchanged file with "0 processed angles" report
- How does system handle contours with fewer than 3 points? Contour is skipped as invalid geometry
- What happens when dart extension would cause self-intersection? System skips this angle and notes it in the output report
- How are floating point precision errors handled in angle calculations? Tolerance of ±0.5° applied to 180° threshold
- What if two inward angles are exactly 220mm apart? Treated as "≤220mm" case with split-segment handling
- How does system handle invalid or corrupted GLC files? System rejects file immediately with technical error code indicating the specific validation failure (e.g., missing ROOMBEGIN, invalid coordinate format, encoding mismatch)

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST accept GLC files containing one or more room contours as input
- **FR-002**: System MUST identify all angles in each contour that exceed 180° (inward-pointing)
- **FR-003**: For each inward angle, system MUST add dart points on adjacent segments at 100mm from the angle vertex
- **FR-004**: System MUST skip inward angles where either adjacent segment is shorter than 50mm
- **FR-005**: When an adjacent segment is shorter than 120mm, system MUST place dart point at distance equal to full segment length (not 100mm)
- **FR-006**: When both adjacent segments are shorter than 120mm, system MUST use the shorter segment's length for dart placement
- **FR-007**: When two inward angles are spaced 220mm or less apart, system MUST split the connecting segment in half and place dart points at distance equal to the half-segment length
- **FR-008**: After adding dart points, system MUST extend new segments by 20mm, or by 10% if segment length is under 100mm
- **FR-009**: System MUST displace the original inward angle vertex inward along the bisector to create the dart cut geometry
- **FR-010**: System MUST rename all points in each contour alphabetically (A, B, C...) in clockwise order after processing
- **FR-011**: System MUST process each contour exactly once with no recursive processing of newly created angles
- **FR-012**: System MUST output a processed GLC file in the same format as input (windows-1251 encoding, CRLF line endings)
- **FR-013**: System MUST display a summary report in an inline panel showing the number of contours found and the count of processed angles per contour with expandable details for each contour
- **FR-014**: System MUST preserve all original GLC metadata (room names, UIDs, dates, material specs) in the output file
- **FR-015**: System MUST execute all processing client-side with no server computation
- **FR-016**: System MUST validate GLC file structure before processing and reject invalid files with specific technical error codes
- **FR-017**: System MUST provide an explicit "Process" button that the user clicks to start dart processing after file upload
- **FR-018**: System MUST name the output file by appending "-processed" suffix to the original input filename (e.g., "room1.glc" → "room1-processed.glc")

### Key Entities

- **Contour**: A closed polygon representing a single ceiling/room outline, defined by an ordered sequence of points arranged in clockwise order
- **Inward Angle**: An angle at a contour vertex that exceeds 180° when measured using signed angle calculation with clockwise traversal (inward angles produce negative signed angles or angles >180°)
- **Dart Point**: A newly created point added to enable dart cut formation
- **Dart Cut**: The geometric modification created by extending segments from dart points and displacing the original inward vertex

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Users can process a GLC file with inward angles and receive a valid output file in under 5 seconds for files with up to 100 contours
- **SC-002**: 100% of inward angles meeting minimum segment length requirements (≥50mm) receive dart processing
- **SC-003**: Processed GLC files can be re-imported into the calculator without errors or data loss
- **SC-004**: Point labeling follows consistent alphabetical clockwise ordering in 100% of processed contours
- **SC-005**: Users can correctly identify how many angles were processed in each contour from the summary report
- **SC-006**: Output files maintain compatibility with GLC format specifications (encoding, line endings, block structure)
