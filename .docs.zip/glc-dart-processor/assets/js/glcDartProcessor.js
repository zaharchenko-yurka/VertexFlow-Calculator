// Re-export processor API from separate modules
import * as proc from './lib/processor.js';

export const MIN_SEGMENT_LENGTH = proc.MIN_SEGMENT_LENGTH;
export const STANDARD_DART_DISTANCE = proc.STANDARD_DART_DISTANCE;
export const VERTEX_DISPLACEMENT = proc.VERTEX_DISPLACEMENT;

export const validateGLC = proc.validateGLC;
export const processDarts = proc.processDarts;
export const generateReport = proc.generateReport;
export const formatError = proc.formatError;

export default {
  MIN_SEGMENT_LENGTH,
  STANDARD_DART_DISTANCE,
  VERTEX_DISPLACEMENT,
  validateGLC,
  processDarts,
  generateReport,
  formatError,
};
