# GLC Dart Processor

Small plugin to process GLC contours and add dart cuts for inward angles. Client-side JavaScript module with an optional WordPress wrapper for easy testing.

Install

1. Copy `glc-dart-processor/` into your WordPress `wp-content/plugins/` for quick local testing.
2. Activate the plugin and visit the converter page.

Development

- Main module: `assets/js/glcDartProcessor.js`
- UI integration example in `dxf-glc-converter` project uses ES6 imports.
