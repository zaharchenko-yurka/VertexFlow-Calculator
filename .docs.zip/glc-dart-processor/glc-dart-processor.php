<?php
/**
 * Plugin Name: GLC Dart Processor
 * Description: Client-side GLC dart processing module as a separate plugin.
 * Version: 0.1.0
 * Author: VertexFlow
 */

if (!defined('ABSPATH')) {
    exit;
}

function gdp_enqueue_scripts() {
    $dir = plugin_dir_url(__FILE__);
    $handle = 'gdp-glc-dart-processor';
    wp_register_script($handle, $dir . 'assets/js/glcDartProcessor.js', array(), '0.1.0', true);
    // Ensure the browser treats this file as an ES module so `export` is valid
    wp_script_add_data($handle, 'type', 'module');
    wp_enqueue_script($handle);

    // Register and enqueue basic plugin styles
    $style_handle = 'gdp-style';
    wp_register_style($style_handle, $dir . 'assets/css/glc-dart-processor.css', array(), '0.1.0');
    wp_enqueue_style($style_handle);
}
add_action('wp_enqueue_scripts', 'gdp_enqueue_scripts');

/**
 * Shortcode handler: [glc_dart_processor]
 * Enqueues the processor script and renders a root container for the UI.
 */
function gdp_render_shortcode($atts = array()) {
    // Ensure script is registered/enqueued
    $handle = 'gdp-glc-dart-processor';
    if (!wp_script_is($handle, 'registered')) {
        $dir = plugin_dir_url(__FILE__);
        wp_register_script($handle, $dir . 'assets/js/glcDartProcessor.js', array(), '0.1.0', true);
        wp_script_add_data($handle, 'type', 'module');
    }
    wp_enqueue_script($handle);

    $html = '<div id="glc-dart-processor-root" class="gdp-root">';
    $html .= '<!-- GLC Dart Processor UI will initialize here -->';
    // Prefer loading the HTML partial from assets/ui.html
    $partial = plugin_dir_path(__FILE__) . 'assets/ui.html';
    if (file_exists($partial)) {
        $html .= file_get_contents($partial);
    } else {
        // Fallback minimal container (keeps JS resilient)
        $html .= '<div id="dxf-glc-converter" class="app"></div>';
    }
    $html .= '</div>';
    return $html;
}
add_shortcode('glc_dart_processor', 'gdp_render_shortcode');
